import random

def generate_reset_code():
    return str(random.randint(1000, 9999))
